# dec2bin
Source code of the dec2bin Python function. This function immediately turns any decimal number(int or float) into it's binary form.
